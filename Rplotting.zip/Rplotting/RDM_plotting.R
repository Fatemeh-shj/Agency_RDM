# # Import data from MATLAB matrices into R, then create bar and line plots
# # to analyze and visualize simultaneity and causality judgments across conditions
# May,2025
#-------------------------------------------------------------------------------

# Load necessary libraries
library(tidyverse)
library(dplyr)
library(nycflights13)
library(R.matlab)
library(ggplot2)
library(patchwork)
library(gridExtra)
library(grid)
library(extrafont) # For better fonts
library(cowplot)

#-------------------------------------------------------------------------------

# Import MATLAB data files
data1 <- readMat("s1data.mat")
data2 <- readMat("s2data.mat")
data3 <- readMat("s3data.mat")
data4 <- readMat("c1data.mat")
data5 <- readMat("c2data.mat")
data6 <- readMat("c3data.mat")

# Extract the matrix from the loaded data
datas1 <- data1$s1data
datas2 <- data2$s2data
datas3 <- data3$s3data
datac1 <- data4$c1data
datac2 <- data5$c2data
datac3 <- data6$c3data

# Number of bins
binnum <- dim(datas1)[1]

# Number of subjects
numsubj <- dim(datas1)[2]

#-------------------------------------------------------------------------------
# Calculating mean, variance and standard error of mean
#-------------------------------------------------------------------------------

# Simultaneity / Mean
ms <- matrix(NA, nrow = dim(datas1)[1], ncol = 3)

ms[, 1] <- apply(datas1[, , 3], 1, mean) # Force
ms[, 2] <- apply(datas2[, , 3], 1, mean) # Free
ms[, 3] <- apply(datas3[, , 3], 1, mean) # phs

# Causality / Mean
mc <- matrix(NA, nrow = dim(datac1)[1], ncol = 3)

mc[, 1] <- apply(datac1[, , 3], 1, mean) # Force
mc[, 2] <- apply(datac2[, , 3], 1, mean) # Free
mc[, 3] <- apply(datac3[, , 3], 1, mean) # phs

# Simultaneity / Variance
vars <- matrix(NA, nrow = dim(datas1)[1], ncol = 3)

vars[, 1] <- apply(datas1[, , 3], 1, var) # Force
vars[, 2] <- apply(datas2[, , 3], 1, var) # Free
vars[, 3] <- apply(datas3[, , 3], 1, var) # phs

# Causality / Variance
varc <- matrix(NA, nrow = dim(datac1)[1], ncol = 3)

varc[, 1] <- apply(datac1[, , 3], 1, var) # Force
varc[, 2] <- apply(datac2[, , 3], 1, var) # Free
varc[, 3] <- apply(datac3[, , 3], 1, var) # phs


# Simultaneity / SEM
err_simul <- matrix(NA, nrow = dim(datas1)[1], ncol = 3)

err_simul[, 1] <- apply(datas1[, , 3], 1, sd) / sqrt(numsubj)
err_simul[, 2] <- apply(datas2[, , 3], 1, sd) / sqrt(numsubj)
err_simul[, 3] <- apply(datas3[, , 3], 1, sd) / sqrt(numsubj)

# Causality / SEM
err_causal <- matrix(NA, nrow = dim(datac1)[1], ncol = 3)

err_causal[, 1] <- apply(datac1[, , 3], 1, sd) / sqrt(numsubj)
err_causal[, 2] <- apply(datac2[, , 3], 1, sd) / sqrt(numsubj)
err_causal[, 3] <- apply(datac3[, , 3], 1, sd) / sqrt(numsubj)


# edges of bar plot(time bins)
edges <- as.matrix(c(-500, -240, -120, -60, 0, 60, 120, 240, 500))

# middle point of time bins
mtdd <- readMat("mtd.mat")
mtd <- mtdd$mtd

#-------------------------------------------------------------------------------
# Plotting data
#-------------------------------------------------------------------------------

# Create a data frame for plotting simultaneity
plot_data <- data.frame(
  Time_Bin = factor(rep(mtd, 3)),
  Mean_Response = c(ms[, 1], ms[, 2], ms[, 3]) * 100,
  # Convert to percentages
  Std_Dev = c(err_simul[, 1], err_simul[, 2], err_simul[, 3]) * 100,
  # Convert to percentages
  Condition = factor(rep(
    c("Force", "Free", "Posthypnotic Suggestion"),
    each = length(mtd)
  ))
)

# Create a data frame for plotting causality
plot_data_causal <- data.frame(
  Time_Bin = factor(rep(mtd, 3)),
  Mean_Response = c(mc[, 1], mc[, 2], mc[, 3]) * 100,
  # Convert to percentages
  Std_Dev = c(err_causal[, 1], err_causal[, 2], err_causal[, 3]) * 100,
  # Convert to percentages
  Condition = factor(rep(
    c("Force", "Free", "Posthypnotic Suggestion"),
    each = length(mtd)
  ))
)
# Custom colors for each condition
custom_colors <- c(
  "Force" = "#fdae61",
  "Free" = "#abd9e9",
  "Posthypnotic Suggestion" = "#2c7bb6"
)
# ,  color ="gray80"
# Create the simultaneity plot (removes legend)
plot_simul <- ggplot(plot_data, aes(x = Time_Bin, y = Mean_Response, fill = Condition)) +
  geom_bar(
    stat = "identity",
    position = position_dodge(width = 0.8),
    width = 0.7,
    alpha = 0.90
  ) +
  geom_errorbar(
    aes(ymin = Mean_Response - Std_Dev, ymax = Mean_Response + Std_Dev),
    position = position_dodge(width = 0.8),
    width = 0.2,
    color = "gray30"
  ) +
  scale_fill_manual(values = custom_colors) +
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 100),
    breaks = seq(0, 100, 10)
  ) +
  labs(title = "(a) Simultaneity Judgements", x = "SOA (ms)", y = "Pr('Simultaneous') (%)") +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "none",
    # Removes legend from this plot
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12,
      family = "Times New Roman"
    ),
    axis.text.y = element_text(size = 12, family = "Times New Roman"),
    axis.title.x = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.title.y = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
    # panel.grid.major.x = element_blank(),  # Removes vertical grid lines
    # panel.grid.major.y = element_line(color = "gray95", linetype = "dashed"),  # Light horizontal grid lines
    # panel.grid.minor = element_blank()  # No minor grid lines for a clean look
  )

# Create the causality plot (keeps legend)
plot_causal <- ggplot(
  plot_data_causal,
  aes(x = Time_Bin, y = Mean_Response, fill = Condition)
) +
  geom_bar(
    stat = "identity",
    position = position_dodge(width = 0.8),
    width = 0.7,
    alpha = 0.90
  ) +
  geom_errorbar(
    aes(ymin = Mean_Response - Std_Dev, ymax = Mean_Response + Std_Dev),
    position = position_dodge(width = 0.8),
    width = 0.2,
    color = "gray30"
  ) +
  scale_fill_manual(values = custom_colors) +
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 100),
    breaks = seq(0, 100, 10)
  ) +
  labs(
    title = "(b) Causality Judgements",
    x = "SOA (ms)",
    y = "Pr('Causal') (%)",
    fill = "Condition"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "bottom",
    # Keeps legend only in this plot
    legend.text = element_text(size = 12, family = "Times New Roman"),
    legend.title = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12,
      family = "Times New Roman"
    ),
    axis.text.y = element_text(size = 12, family = "Times New Roman"),
    axis.title.x = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.title.y = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
    # panel.grid.major.x = element_blank(),  # Removes vertical grid lines
    # panel.grid.major.y = element_line(color = "gray95", linetype = "dashed"),  # Light horizontal grid lines
    # panel.grid.minor = element_blank()  # No minor grid lines for a clean look
  )

# Combine the plots while ensuring **only one legend is displayed**
combined_plot <- (plot_simul | plot_causal) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "bottom",
    # Moves the legend to the bottom
    legend.text = element_text(size = 12, family = "Times New Roman"),
    legend.title = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    )
  )


# Convert combined figure to a grob so gridExtra can correctly handle it
combined_grob <- as_grob(combined_plot)

# Arrange the plot with correct spacing
final_plot <- grid.arrange(combined_grob, ncol = 1, heights = c(10, 1.5))

# Display the final plot
print(final_plot)

# Save the figure with proper formatting for use in your paper
# ggsave("Bar_combined.png", combined_grob, width = 12, height = 6, dpi = 300)

#-------------------------------------------------------------------------------
# plot each judgement data in a separate figure
#-------------------------------------------------------------------------------
# Create the simultaneity plot
plot_simul <- ggplot(plot_data, aes(x = Time_Bin, y = Mean_Response, fill = Condition)) +
  geom_bar(
    stat = "identity",
    position = position_dodge(width = 0.8),
    width = 0.7,
    alpha = 0.90
  ) +
  geom_errorbar(
    aes(ymin = Mean_Response - Std_Dev, ymax = Mean_Response + Std_Dev),
    position = position_dodge(width = 0.8),
    width = 0.2,
    color = "gray30"
  ) +
  scale_fill_manual(values = custom_colors) +
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 100),
    breaks = seq(0, 100, 10)
  ) +
  labs(x = "SOA (ms)", y = "Pr('Simultaneous') (%)") +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "none",
    # Removes legend from this plot
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12,
      family = "Times New Roman"
    ),
    axis.text.y = element_text(size = 12, family = "Times New Roman"),
    axis.title.x = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.title.y = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
    # panel.grid.major.x = element_blank(),  # Removes vertical grid lines
    # panel.grid.major.y = element_line(color = "gray95", linetype = "dashed"),  # Light horizontal grid lines
    # panel.grid.minor = element_blank()  # No minor grid lines for a clean look
  )

# Create the causality plot
plot_causal <- ggplot(
  plot_data_causal,
  aes(x = Time_Bin, y = Mean_Response, fill = Condition)
) +
  geom_bar(
    stat = "identity",
    position = position_dodge(width = 0.8),
    width = 0.7,
    alpha = 0.90
  ) +
  geom_errorbar(
    aes(ymin = Mean_Response - Std_Dev, ymax = Mean_Response + Std_Dev),
    position = position_dodge(width = 0.8),
    width = 0.2,
    color = "gray30"
  ) +
  scale_fill_manual(values = custom_colors) +
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 100),
    breaks = seq(0, 100, 10)
  ) +
  labs(x = "SOA (ms)", y = "Pr('Causal') (%)", fill = "Condition") +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "bottom",
    # Keeps legend only in this plot
    legend.text = element_text(size = 12, family = "Times New Roman"),
    legend.title = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12,
      family = "Times New Roman"
    ),
    axis.text.y = element_text(size = 12, family = "Times New Roman"),
    axis.title.x = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.title.y = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
    # panel.grid.major.x = element_blank(),  # Removes vertical grid lines
    # panel.grid.major.y = element_line(color = "gray95", linetype = "dashed"),  # Light horizontal grid lines
    # panel.grid.minor = element_blank()  # No minor grid lines for a clean look
  )
# Display each plot separately
print(plot_simul)
print(plot_causal)


#-------------------------------------------------------------------------------
# LINE PLOT
#-------------------------------------------------------------------------------

# Custom colors for each condition
custom_colors <- c(
  "Force" = "#fdae61",
  "Free" = "#abd9e9",
  "Posthypnotic Suggestion" = "#2c7bb6"
)

# Simultaneity plot with error bars matching line color
plot_simul <- ggplot(
  plot_data,
  aes(
    x = Time_Bin,
    y = Mean_Response,
    color = Condition,
    group = Condition
  )
) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  geom_errorbar(
    aes(
      ymin = Mean_Response - Std_Dev,
      ymax = Mean_Response + Std_Dev,
      color = "gray50"
    ),
    width = 0.1,
    position = position_dodge(width = 0.3)
  ) +
  scale_color_manual(values = custom_colors) +
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 100),
    breaks = seq(0, 100, 10)
  ) +
  labs(title = "(a) Simultaneity Judgements", x = "SOA (ms)", y = "Pr('Simultaneous') (%)") +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "none",
    # Removes legend from simultaneity plot
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12,
      family = "Times New Roman"
    ),
    axis.text.y = element_text(size = 12, family = "Times New Roman"),
    axis.title.x = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.title.y = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "gray85", linetype = "dotted"),
    panel.grid.minor = element_blank()
  )

# Causality plot with error bars matching line color
plot_causal <- ggplot(
  plot_data_causal,
  aes(
    x = Time_Bin,
    y = Mean_Response,
    color = Condition,
    group = Condition
  )
) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  geom_errorbar(
    aes(
      ymin = Mean_Response - Std_Dev,
      ymax = Mean_Response + Std_Dev,
      color = "gray50"
    ),
    width = 0.1,
    position = position_dodge(width = 0.3)
  ) +
  scale_color_manual(values = custom_colors) +
  scale_y_continuous(
    expand = c(0, 0),
    limits = c(0, 100),
    breaks = seq(0, 100, 10)
  ) +
  labs(
    title = "(b) Causality Judgements",
    x = "SOA (ms)",
    y = "Pr('Causal') (%)",
    color = "Condition"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "bottom",
    # Ensures the **only** legend appears here
    legend.text = element_text(size = 12, family = "Times New Roman"),
    legend.title = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 12,
      family = "Times New Roman"
    ),
    axis.text.y = element_text(size = 12, family = "Times New Roman"),
    axis.title.x = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    axis.title.y = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    ),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "gray85", linetype = "dotted"),
    panel.grid.minor = element_blank()
  )

# Combine the plots and ensure **only one legend appears**
combined_plot <- (plot_simul | plot_causal) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "bottom",
    legend.text = element_text(size = 12, family = "Times New Roman"),
    legend.title = element_text(
      size = 14,
      face = "bold",
      family = "Times New Roman"
    )
  )

# Convert combined figure to a grob so gridExtra can correctly handle it
combined_grob <- as_grob(combined_plot)

# Arrange the plot with correct spacing
final_plot <- grid.arrange(combined_grob, ncol = 1, heights = c(10, 1.5))

# Display the final plot
print(final_plot)

# Save the figure for your paper
# ggsave("Line_combined.png", combined_grob, width = 12, height = 6, dpi = 300)
