function  runCue(display,cueTime,cueState,cond)
% create a triangle

red=[255 0 0];
green=[0 255 0];
blue=[0 0 255];
yellow=[255 255 0];
magneta=[255 0 255];
cyan=[0,255,255];

% brown=[ 218 160 109];
% brown=[ 196 164 132];
brown=[ 123 63 0];
% purple=[255 0 200];
black=[0 0 0];
purple=[191,64,191];

% 
% global wHeight;
% global wWidth;
center = display.resolution/2;
xCenter=center(1);
yCenter=center(2);
a=angle2pix(display,0.450);
cueRect= [xCenter-a yCenter-a xCenter+a yCenter+a];

windowPtr=display.windowPtr;

if cond==1 && cueState==1 %force,left
    Screen('FillRect', windowPtr, red , cueRect )
    Screen('Flip' , windowPtr);
    WaitSecs(cueTime);

elseif cond==1 && cueState==2 %force,right

    Screen('FillRect', windowPtr, blue , cueRect )
    Screen('Flip' , windowPtr);
    WaitSecs(cueTime);
    
elseif cond==2 && cueState==1 %free
    
    Screen('FillRect', windowPtr, purple , cueRect )
    Screen('Flip' , windowPtr);
    WaitSecs(cueTime);

elseif cond==2 && cueState==2%free

    Screen('FillRect', windowPtr, brown , cueRect )
    Screen('Flip' , windowPtr);
    WaitSecs(cueTime);
elseif  cond==3  && cueState==1 %phs,left

    Screen('FillRect', windowPtr, yellow , cueRect )
    Screen('Flip' , windowPtr);
    WaitSecs(cueTime);

elseif cond==3 && cueState==2 %phs,right

    Screen('FillRect', windowPtr, green , cueRect )
    Screen('Flip' , windowPtr);
    WaitSecs(cueTime);


end
end


