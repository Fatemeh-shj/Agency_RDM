function  FixationPoint(display,fixationtime)
    %draw a dot fixation point

    center = display.resolution/2;
    xCenter=center(1);
    yCenter=center(2);
    radius           = angle2pix(display,0.179);%10;
    circleRectLeft   = xCenter - radius;     % first rect of circle
    circleRectTop    = yCenter - radius;     % second rect of circle
    circleRectRight  = xCenter + radius;    % third rect of circle
    circleRectBottom = yCenter + radius;  % forth rect of circle
    circleRect       = [circleRectLeft, circleRectTop, circleRectRight, circleRectBottom]; % rect of circle
    circleColor      = [255 255 255];
    windowPtr=display.windowPtr;
    Screen('FillOval' , windowPtr, circleColor , circleRect );
    Screen('Flip' , display.windowPtr );

    %wait for ? seconds(500 ms = 0.5 sec)
    WaitSecs(fixationtime);
end