function [RT,key,duration,te,X,Y,Gd]=MovingDots(display,dots,meanRT,latency)
% movingDots(display,dots,duration)
%
% Animates a field of moving dots based on parameters defined in the 'dots'
% structure over a period of seconds defined by 'duration'.
%MovingDots
% The 'dots' structure must have the following parameters:
%
%   nDots            Number of dots in the field
%   speed            Speed of the dots (degrees/second)
%   direction        Direction 0-360 clockwise from upward
%   lifetime         Number of frames for each dot to live
%   apertureSize     [x,y] size of circular aperture (degrees)
%   center           [x,y] Center of the aperture (degrees)
%   color            Color of the dot field [r,g,b] from 0-255
%   size             Size of the dots (in pixels)
%   coherence        Coherence from 0 (incoherent) to 1 (coherent)
%
% 'dots' can be an array of structures so that multiple fields of dots can
% be shown at the same time.  The order that the dots are drawn is
% scrambled across fields so that one field won't occlude another.
%
% The 'display' structure requires the fields:
%    width           Width of screen (cm)
%    dist            Distance from screen (cm)
% And can also use the fields:
%    skipChecks      If 1, turns off timing checks and verbosity (default 0)
%    fixation        Information about fixation (see 'insertFixation.m')
%    screenNum       screen number
%    bkColor         background color (default is [0,0,0])
%    windowPtr       window pointer, set by 'OpenWindow'
%    frameRate       frame rate, set by 'OpenWindow'
%    resolution      pixel resolution, set by 'OpenWindow'

% Fatemeh Jannesari,2023
display.frameRate
key=[];
%Calculate total number of dots across fields
nDots = sum([dots.nDots]);

%Zero out the color and size vectors
colors = zeros(3,nDots);
sizes = zeros(1,nDots);
% S=angle2pix(display,0.149);
% sizes=S;
%Generate a random order to draw the dots so that one field won't occlude
%another field.
order=  randperm(nDots);
global wWidth
global wHeight
Dur=latency+meanRT
duration=horzcat(Dur,.100,1-Dur);
coherency=[0,1,0];
speed=[.1,6,.1];
RT=[];
GD=[];
Rectstart=[0 0 wWidth wHeight];  

% KbQueueCreate();
%% Loop through the frames
keyIsDown=0;
FlushEvents();
KbName('UnifyKeyNames');
ActiveKeys=[KbName('ESCAPE'), KbName('d'),KbName('l') ];
RestrictKeysForKbCheck(ActiveKeys);
% for d=1:length(duration)
%     nFrames(d) = secs2frames(display,duration(d));
% end
% m=[1,nFrames(1);(nFrames(1)+1),(nFrames(1)+nFrames(2));...
%     (nFrames(1)+nFrames(2)+1),(nFrames(1)+nFrames(2)+nFrames(3))];
%     GD=zeros(dots.nDots,sum(nFrames));
%     pix_y=zeros(dots.nDots,sum(nFrames));
%     pix_x=zeros(dots.nDots,sum(nFrames));
%  tt=GetSecs();
for d=1:length(duration)
    
    dots.coherence=coherency(d);
    dots.speed=speed(d);
    count = 1;
    Screen('BlendFunction',display.windowPtr , GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    for i=1:length(dots) %Loop through the fields


        %Calculate the left, right top and bottom of each aperture (in degrees)
        l(i) = dots(i).center(1)-dots(i).apertureSize(1)/2;
        r(i) = dots(i).center(1)+dots(i).apertureSize(1)/2;
        b(i) = dots(i).center(2)-dots(i).apertureSize(2)/2;
        t(i) = dots(i).center(2)+dots(i).apertureSize(2)/2;

        %Generate random starting positions
        dots(i).x = (rand(1,dots(i).nDots)-.5)*dots(i).apertureSize(1) + dots(i).center(1);
        dots(i).y = (rand(1,dots(i).nDots)-.5)*dots(i).apertureSize(2) + dots(i).center(2);

        %Create a direction vector for a given coherence level
        direction = rand(1,dots(i).nDots)*360;
        nCoherent = ceil(dots(i).coherence*dots(i).nDots);  %Start w/ all random directions
        direction(1:nCoherent) = dots(i).direction;  %Set the 'coherent' directions

        %Calculate dx and dy vectors in real-world coordinates
        dots(i).dx = -dots(i).speed*cos(direction*pi/180)/display.frameRate;
        dots(i).dy = dots(i).speed*sin(direction*pi/180)/display.frameRate;
        dots(i).life = ceil(rand(1,dots(i).nDots)*dots(i).lifetime);
        %Fill in the 'colors' and 'sizes' vectors for this field
        id = count:(count+dots(i).nDots-1);  %index into the nDots length vector for this field
        colors(:,order(id)) = repmat(dots(i).color(:),1,dots(i).nDots);

        sizes(order(id)) = repmat(dots(i).size,1,dots(i).nDots);

        count = count+dots(i).nDots;
    end


    %Zero out the screen position vectors and the 'goodDots' vector
    pixpos.x = zeros(1,nDots);
    pixpos.y = zeros(1,nDots);
    
    %     FlushEvents();
    %     startTime= GetSecs();
    % %     tt=tic;
    %     totalduraiton=duration(d);
    %     count1=1;
    %     while GetSecs()-startTime <= totalduraiton

    for frameNum=1:nFrames(d)
        count = 1;
        %         keyIsDown=0;
        for i=1:length(dots)  %Loop through the fields

            %Update the dot position's real-world coordinates
            dots(i).x = dots(i).x + dots(i).dx;
            dots(i).y = dots(i).y + dots(i).dy;


            %Move the dots that are outside the aperture back one aperture width.
            dots(i).x(dots(i).x<l(i)) = dots(i).x(dots(i).x<l(i)) + dots(i).apertureSize(1);
            dots(i).x(dots(i).x>r(i)) = dots(i).x(dots(i).x>r(i)) - dots(i).apertureSize(1);
            dots(i).y(dots(i).y<b(i)) = dots(i).y(dots(i).y<b(i)) + dots(i).apertureSize(2);
            dots(i).y(dots(i).y>t(i)) = dots(i).y(dots(i).y>t(i)) - dots(i).apertureSize(2);

            %Increment the 'life' of each dot
            dots(i).life = dots(i).life+1;

            %Find the 'dead' dots
            deadDots = mod(dots(i).life,dots(i).lifetime)==0;

            %Replace the positions of the dead dots to random locations
            dots(i).x(deadDots) = (rand(1,sum(deadDots))-.5)*dots(i).apertureSize(1) + dots(i).center(1);
            dots(i).y(deadDots) = (rand(1,sum(deadDots))-.5)*dots(i).apertureSize(2) + dots(i).center(2);

            %Calculate the index for this field's dots into the whole list of
            %dots.  Using the vector 'order' means that, for example, the first
            %field is represented not in the first n values, but rather is
            %distributed throughout the whole list.
            id = order(count:(count+dots(i).nDots-1));

            %Calculate the screen positions for this field from the real-world coordinates
            pixpos.x(id) = angle2pix(display,dots(i).x)+ display.resolution(1)/2;
            pixpos.y(id) = angle2pix(display,dots(i).y)+ display.resolution(2)/2;
%             X(:,frameNum,d)=pixpos.x;
%             Y(:,frameNum,d)=pixpos.y;

            %Determine which of the dots in this field are outside this field's
            %circular aperture
            goodDots(id) = (dots(i).x-dots(i).center(1)).^2/(dots(i).apertureSize(1)/2)^2 + ...
                (dots(i).y-dots(i).center(2)).^2/(dots(i).apertureSize(2)/2)^2 < 1;
%             Gd(:,frameNum,d)=goodDots;
            count = count+dots(i).nDots;

        end
        
            X(:,frameNum,d)=pixpos.x;
            Y(:,frameNum,d)=pixpos.y;
            Gd(:,frameNum,d)=goodDots;
%                         X(frameNum,:,d)=pixpos.x;
%             Y(frameNum,frameNum,d)=pixpos.y;
%             Gd(frameNum,frameNum,d)=goodDots;
%             GD(:,m(d,1):m(d,2))=goodDots;
%             pix_y(:,m(d,1):m(d,2))=pixpos.y;
%             pix_x(:,m(d,1):m(d,2))=pixpos.x;

    end
%             GD(:,m(d,1):m(d,2))=goodDots;
%             pix_y(:,m(d,1):m(d,2))=pixpos.y;
%             pix_x(:,m(d,1):m(d,2))=pixpos.x;
end

%%
topPriorityLevel=MaxPriority(display.windowPtr);
tt=GetSecs();
TStart=GetSecs;
ifi=Screen('GetFlipInterval',display.windowPtr)

waitframes=1;
Priority(topPriorityLevel);
vbl=Screen('Flip',display.windowPtr)


for d=1:length(duration)
    FlushEvents();

    count1=1;


      T = 1000./display.frameRate

%        T = ifi./1000;
    for frameNum=1:nFrames(d)
        frameNum
        t0=GetSecs();
        
        %Draw all fields at once
        GD=Gd(:,frameNum,d);
        pix_x=[X(:,frameNum,d)]';
        pix_y=[Y(:,frameNum,d)]';

        Screen('BlendFunction',display.windowPtr , GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        Screen('DrawDots',display.windowPtr,[pix_x(GD);pix_y(GD)], dots.size, [255 255 255],[0,0],3);

        [VBLTimestamp ,StimulusOnsetTime ,FlipTimestamp , Missed, Beampos]=Screen('Flip' , display.windowPtr);
%         vbl+(waitframes-.5)*ifi
            vbl1=abs(VBLTimestamp-FlipTimestamp)
Missed 
Beampos
            pressed = 0;
            while (1000*(GetSecs()-t0))<T
                
                 [keyIsDown,secs,keyCode]=KbCheck;

                if keyIsDown==1 && ~pressed

                    key=KbName(find(keyCode));

                    RT=secs-TStart;

                    pressed = 1;
                end


                WaitSecs(.001);
            end

       
        if RT<.350
            break;
        end
        if RT>.750
            break;
        end
% if RT>0.750 && pressed==0
%     break;
% end

        %                         Screen('DrawTexture',display.windowPtr,soonTexture,[],Rectstart);
        %                         Screen('Flip' , display.windowPtr);
        %                         WaitSecs(0.5);
        %                         d=length(duration);
        %                         frameNum=nFrames(d);
        %             %           trialValidation(trial)=2; %2=too soon
        %
        %
        %                     elseif RT>.750
        %
        %                         Screen('DrawTexture',display.windowPtr,lateTexture,[],Rectstart);
        %                         Screen('Flip' , display.windowPtr);
        %                         WaitSecs(0.5);
        %                         d=length(duration);
        %                         frameNum=nFrames(d);
        % %                       d=length(duration)+1;
        %                         trialValidation(trial)=3; %=too late
        %
        %                     end

    end

    count1=count1+1;
Priority(0);
    % end

end
% end

te=GetSecs()-tt
RestrictKeysForKbCheck([]);
% disp(strcat('meanRT=', num2str(meanRT),'latency=',num2str(latency),'duration=',num2str(Dur),'-', num2str(duration),'time = ',num2str(te)));
if isempty(RT)
    RT=2;
end

% m=[1,nFrames(1);(nFrames(1)+1),(nFrames(1)+nFrames(2));...
%     (nFrames(1)+nFrames(2)+1),(nFrames(1)+nFrames(2)+nFrames(3))];
% for d=1:length(duration)
% 
%    
%        pix_x(:,m(d,1):m(d,2))=X(:,m(d,1):m(d,2),d);
%        pix_y(:,m(d,1):m(d,2))=Y(:,m(d,1):m(d,2),d);
%        GD(:,m(d,1):m(d,2))=GD(:,m(d,1):m(d,2),d);
%   
% 
% end
% ifi=Screen('GetFlipInterval',display.windowPtr)