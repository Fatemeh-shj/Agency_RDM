
%         responsemat(trial,1)=block; %num block
%         responsemat(trial,2)=cond; %condition
%         responsemat(trial,3)=trialinfOrder(trial,1); %time delays
%         responsemat(trial,4)=trialinfOrder(trial,2); % cueState
%         responsemat(trial,5)=trialinfOrder(trial,3); %judgecond
%         responsemat(trial,6)=reactiontime(trial); %reactiontimes
%         responsemat(trial,7)=response(trial); % pressedkey
%         responsemat(trial,8)=trialValidation(trial); % if pressedkey was true ==1
%         responsemat(trial,9)=0; %cj answer : 0 no/1 yes
%         responsemat(trial,10)=1; %sj answer : 0 no/1 yes
%         responsemat(:,11)=0; %train or not train=1/ main=0
%         responsemat(:,12)=Subject;
%         responsemat(trial,13)=gender; %Man=1 / Woman=2
%         responsemat(trial,14)=dominantHand; %Left=1 / Right=2
%         responsemat(trial,15)=age;
%         responsemat(trial,16)=pressedkeycode; 1 for left/2 for right
%         responsemat(trial,17)=sj pressed key code : 1 for left/ 2 for right
%         responsemat(trial,18)=cj pressed key code : 1 for left/ 2 fo     r right
%         responsemat(trial,19)=RTsimuljudge;
%         responsemat(trial,20)=RTcausaljudge;


%
%% set path

clear all
close all
clc
path_ = cd;

f = filesep;
addpath([path_ f 'myfunc']);
addpath([path_ f 'mydata']);
addpath([path_ f 'images']);
addpath([path_ f 'meandata']);
path_images = [path_ f 'images'];

files = dir (path_images);
files = files(3:end);
path_data = [path_ f 'mydata'];
path_means=[path_ f 'meandata'];


%% Set display parameters
%
display.dist = 70;  %cm distance from monitor
display.width = 30; %cm
display.skipChecks = 1; %avoid Screen's timing checks and verbosity
PsychImaging('PrepareConfiguration');
PsychImaging('AddTask', 'General', 'UseRetinaResolution');

global wHeight;
global wWidth;

%% input dialogue
% dialogue input box to get session info
prompt         = {'subject name:','subject number:','gender(man=1/woman=2):','age:','left=1/right=2 handed:'};

dlgtitle       = 'Session Info ';
dims           = [1 45];
opts           = 'on';
answer         = inputdlg(prompt, dlgtitle, dims);
Name           = answer{1};
subject        = answer{2};
gender         = answer{3}; %MAN=1  Woman=2
age            = answer{4};
dominantHand   = answer{5}; %Left=1   Right=2

age=str2num(age);
dominantHand=str2num(dominantHand);
Subject=str2num(subject);
gender=str2num(gender);

dt=datetime('now','format','d-MMM-y-HH.mm.ss');
date=string(dt);
strname=sprintf('datasetMA_%d_%s_%s',Subject,Name,date);

mkdir([path_data f strname]);

%% Set dots parameters

dots.nDots=80;
dots.lifetime=20; %Frames
dots.speed=.1; %degree/sec
dots.apertureSize= [6,6]; %size of diameter of circular aperture in degrees.
dots.color=[255 255 255]; %white
dots.center = [0,0];


%% images setting

cjqdata=imread(strcat([path_images f files(1).name])); % question of causality
sjqdata=imread(strcat([path_images f files(2).name])); % question of simultaniety
baledata=imread(strcat([path_images f files(3).name])); % yes response
kheirdata=imread(strcat([path_images f files(4).name])); % no response
rest1data=imread(strcat([path_images f files(5).name])); % rest time, in middle of the task
rest2data=imread(strcat([path_images f files(6).name])); % rest time 
start1data=imread(strcat([path_images f files(7).name])); % explanation of the task in start of the task
start2data=imread(strcat([path_images f files(8).name])); % explanation of the task in start of the task
soondata=imread(strcat([path_images f files(10).name])); % too soon error message
latedata=imread(strcat([path_images f files(9).name])); % too late error message
wrongkeydata=imread(strcat([path_images f files(11).name])); % wrong key error message



%% trial direction and dot direction


nbtrials=24; %number of trials per block
lefthand= ones(nbtrials/2,1);
righthand=ones(nbtrials/2,1)+1;
actionkey=vertcat(lefthand,righthand);

times=[-.300,-0.100,-0.030,0.030,0.100,.300]'; % time delays
times=repmat(times,[4,1]);
ITI=0.25; %1 second

trialinflist=horzcat(times,actionkey); 


%% define conditions

fixationtime = 0.5; % 500 ms fixation point
cueTime=.250; % colored squre as cue for subject based on instructions
sumtrial=6*3*16; % total number of trials
numblock=sumtrial/nbtrials; % number of blocks
ResponseMat_all=[]; % create a matrix for all responses
condition=[1;2;3]; %1=force,2=free ,3= phs
conditionlist= repmat(condition,[numblock/length(condition),1]);
conditionlist=Shuffle(conditionlist);
jcond=[1;2];
judgementlist=repmat(jcond,[(nbtrials/length(jcond)),1]); % creat a matix for random  order of shwoing  judgments
meanRT_all=[];
meanRT=[];
numberofTrial=[];
%%
TRAINorNOT=0;
meanRTresult = MEANRT_calculater(TRAINorNOT,Subject);

%%
% Define a key code lookup table
KbName('UnifyKeyNames');
keyCodes = struct('Left', KbName('d'), 'Right', KbName('l'), 'Escape', KbName('ESCAPE'));

%% start task
for block =1:numblock
    numTrial=nbtrials;
    cond= conditionlist(block);

    responsemat=nan(numTrial,20);
    response=nan(numTrial,1);
    S=Shuffle(1:nbtrials);
    trialValidation=ones(1,numTrial);
    reactiontime=nan(1,numTrial);


    for k=1:length(S)

        trialinfOrder(k,1)= trialinflist(S(k),1); % first column= cueState
        trialinfOrder(k,2)= trialinflist(S(k),2); % time delay for coherent dot motion
        trialinfOrder(k,3)= judgementlist(S(k)); % 1: cj first,2: sj  first


    end



    %Start the block
    display = OpenWindow(display);
    dots.size = angle2pix(display,.12); %diameter degree
    wptr = display.windowPtr;
    wWidth = display.resolution(1);
    wHeight = display.resolution(2);

    Rectstart=[0 0 wWidth wHeight];
    HideCursor();

    if block==1
        startTexture1=Screen('MakeTexture',wptr,start1data);
        Screen('DrawTexture',wptr,startTexture1,[],Rectstart);
        Screen('Flip' , display.windowPtr);
        [secs, keyCode, deltaSecs] = KbPressWait;
        FlushEvents();
        startTexture2=Screen('MakeTexture',wptr,start2data);
        Screen('DrawTexture',wptr,startTexture2,[],Rectstart);
        Screen('Flip' , display.windowPtr);
        [secs, keyCode, deltaSecs] = KbPressWait;

    elseif block==((numblock)/2)+1
        restTexture1=Screen('MakeTexture',wptr,rest1data);
        Screen('DrawTexture',wptr,restTexture1,[],Rectstart);
        Screen('Flip' , display.windowPtr);
        [secs, keyCode, deltaSecs] = KbPressWait;

    end
    %%  set parameters for judgement questions

    center = display.resolution/2;
    xCenter=center(1);
    yCenter=center(2);

    sjqTexture=Screen('MakeTexture',wptr ,sjqdata);
    cjqTexture=Screen('MakeTexture',wptr,cjqdata);
    yesTexture= Screen('MakeTexture',wptr,baledata);
    NoTexture=Screen('MakeTexture',wptr,kheirdata);
    soonTexture= Screen('MakeTexture',wptr,soondata);
    lateTexture=Screen('MakeTexture',wptr,latedata);
    wrongTexture=Screen('MakeTexture',wptr,wrongkeydata);

    centerJudge1= [xCenter-wWidth/4 , yCenter+wHeight/4];
    centerJudge2= [xCenter+wWidth/4, yCenter+wHeight/4];
    RectJudgeSize=70;
    Norect = [centerJudge1(1)- RectJudgeSize centerJudge1(2)-RectJudgeSize...
        centerJudge1(1)+RectJudgeSize  centerJudge1(2)+RectJudgeSize];
    Yesrect = [centerJudge2(1)- RectJudgeSize centerJudge2(2)-RectJudgeSize...
        centerJudge2(1)+RectJudgeSize  centerJudge2(2)+RectJudgeSize];



    tstart=tic;
    trial=1;

    while trial<=numTrial

        FlushEvents;
        FixationPoint(display,fixationtime);
        %choose either left or right action key, for cue
        cueState =trialinfOrder(trial,2);
        dots.direction = 90; %  always up
        latency= trialinfOrder(trial,1);
        Screen('Flip' , display.windowPtr);
        runCue(display,cueTime,cueState,cond);
        Screen('Flip' , display.windowPtr);
        judgecond = trialinfOrder(trial,3);

        %Show the stimulus
        keyIsDown=0;
        FlushEvents();
        activeKeys=[keyCodes.Left,keyCodes.Right,keyCodes.Escape];
        RestrictKeysForKbCheck(activeKeys);


        if isempty(meanRT)|| isnan(meanRT)
            meanRT=meanRTresult;
        end

        %         TStart=GetSecs;

        %start stimulus
        %         [RT,key,duration,te,X,Y,Gd]=MovingDots(display,dots,meanRT,latency);
        [RT,key,duration,te,X,Y,Gd]=NewMovingDot(display,dots,meanRT,latency,cond,cueState,keyCodes);
        pressedKey=key;

        % Get the pressed key code
        pressedKeyCode = KbName(pressedKey); % Convert pressedKey to key code

        allkeys{trial}=key;
        reactiontime(trial)=RT;


        if reactiontime(trial)<.350

            Screen('DrawTexture',wptr,soonTexture,[],Rectstart);
            Screen('Flip' , display.windowPtr);
            WaitSecs(0.250);
            trialValidation(trial)=2; %2=too soon


        elseif reactiontime(trial)>.750 || isempty(pressedKeyCode)

            Screen('DrawTexture',wptr,lateTexture,[],Rectstart);
            Screen('Flip' , display.windowPtr);
            WaitSecs(0.250);
            trialValidation(trial)=3; %=too late

        end

        if pressedKeyCode == keyCodes.Right
            responsemat(trial,16)=2;
        elseif pressedKeyCode == keyCodes.Left
            responsemat(trial,16)=1;
        elseif pressedKeyCode == keyCodes.Escape
            block=numblock+1;
            Screen('CloseAll');
            break;

        end

        if cond==1

            if isempty(pressedKeyCode)
                response(trial,1)=0;
                trialValidation(trial)=4; %4=not pressed

            elseif pressedKeyCode == keyCodes.Right && cueState==2 % k for right
                response(trial,1)=2;

            elseif pressedKeyCode == keyCodes.Left && cueState==1 %f for left
                response(trial,1)=1;

            elseif pressedKeyCode == keyCodes.Left && cueState==2
                response(trial,1)=3;
                trialValidation(trial)=5; %5=wrong key
                Screen('DrawTexture',wptr,wrongTexture,[],Rectstart);
                Screen('Flip' , display.windowPtr);
                WaitSecs(0.250);

            elseif pressedKeyCode == keyCodes.Right && cueState==1
                response(trial,1)=4;
                trialValidation(trial)=5; %5=wrong key
                Screen('DrawTexture',wptr,wrongTexture,[],Rectstart);
                Screen('Flip' , display.windowPtr);
                WaitSecs(0.250);

            end

        elseif cond==2

            if isempty(pressedKeyCode)
                response(trial,1)=0;
                trialValidation(trial)=4; %4=not pressed
            elseif pressedKeyCode == keyCodes.Left % pressedkey=f
                response(trial,1)=1;
            elseif pressedKeyCode == keyCodes.Right
                response(trial,1)=2;




            end

        elseif cond==3 %phs

            if isempty(pressedKeyCode)
                response(trial,1)=0;
                trialValidation(trial)=4; %4=not pressed
            elseif pressedKeyCode == keyCodes.Right && cueState==2 % k for right
                response(trial,1)=2;
            elseif pressedKeyCode == keyCodes.Left && cueState==1 %f for left
                response(trial,1)=1;
            elseif pressedKeyCode == keyCodes.Left && cueState==2
                response(trial,1)=3;

            elseif pressedKeyCode == keyCodes.Right && cueState==1
                response(trial,1)=4;


            end


        end


        if trialValidation(trial)~=1
            numTrial=numTrial+1;
            trialValidation(numTrial)=1;
            trialinfOrder(numTrial,:)=trialinfOrder(trial,:);
            response(numTrial)=nan;
            responsemat(numTrial,:)=nan;
        end

        responsemat(trial,1)=block; %num block
        responsemat(trial,2)=cond; %condition
        responsemat(trial,3)=trialinfOrder(trial,1); %time delays
        responsemat(trial,4)=trialinfOrder(trial,2); % cueState
        responsemat(trial,5)=trialinfOrder(trial,3); %judgecond
        responsemat(trial,6)=reactiontime(trial); %reactiontimes
        responsemat(trial,7)=response(trial); % pressedkey
        responsemat(trial,8)=trialValidation(trial); % if pressedkey was true ==1

        % judgments
        FlushEvents();
        keyIsDown=0;
        KbName('UnifyKeyNames');
        activeKeys=[keyCodes.Left,keyCodes.Right,keyCodes.Escape];

        RestrictKeysForKbCheck(activeKeys);

        if trialValidation(trial)==1

            if judgecond==1 %cj first
                FlushEvents();
                keyIsDown=0;
                KbName('UnifyKeyNames');
                causalkey=[];
                % ts=GetSecs;
                Screen('DrawTexture',wptr,cjqTexture,[],Rectstart);
                Screen('DrawTexture',wptr,NoTexture,[],Norect );
                Screen('DrawTexture',wptr,yesTexture,[],Yesrect );
                ts=GetSecs;
                Screen('Flip' , display.windowPtr);
                [secs, keyCode, deltaSecs] = KbPressWait;


                causalkey= KbName(find(keyCode));
                RTcausaljudge=secs-ts;
                responsemat(trial,20)=RTcausaljudge;




                if causalkey == KbName(keyCodes.Left)  %left key press=no
                    responsemat(trial,9)=0; %cj answer
                    responsemat(trial,18)=1;
                elseif causalkey == KbName(keyCodes.Right ) %right key press=yes
                    responsemat(trial,9)=1; %cj answer
                    responsemat(trial,18)=2;
                elseif causalkey== KbName(keyCodes.Escape)
                    Screen('CloseAll');
                    break;
                end

                simulkey=[];
                keyIsDown=0;
                KbName('UnifyKeyNames');
                FlushEvents();
                % ts=GetSecs;
                Screen('DrawTexture',wptr,sjqTexture,[],Rectstart);
                Screen('DrawTexture',wptr,yesTexture,[],Yesrect );
                Screen('DrawTexture',wptr,NoTexture,[],Norect );
                ts=GetSecs;
                Screen('Flip' , display.windowPtr);
                [secs, keyCode, deltaSecs] = KbPressWait;

                simulkey= KbName(find(keyCode));
                RTsimuljudge=secs-ts;
                responsemat(trial,19)=RTsimuljudge;




                if simulkey==KbName(keyCodes.Left) %left key press=no
                    responsemat(trial,10)=0; %sj answer
                    responsemat(trial,17)=1;
                elseif simulkey==KbName(keyCodes.Right) %right key press=yes
                    responsemat(trial,10)=1; %sj answer
                    responsemat(trial,17)=2;
                elseif simulkey == KbName(keyCodes.Escape)
                    Screen('CloseAll');
                    break;
                end



            elseif judgecond==2 %sj first
                FlushEvents();
                keyIsDown=0;
                KbName('UnifyKeyNames');
                simulkey=[];
                % ts=GetSecs;
                Screen('DrawTexture',wptr,sjqTexture,[],Rectstart);
                Screen('DrawTexture',wptr,yesTexture,[],Yesrect );
                Screen('DrawTexture',wptr,NoTexture,[],Norect );
                ts=GetSecs;
                Screen('Flip' , display.windowPtr);
                [secs, keyCode, deltaSecs] = KbPressWait;

                simulkey= KbName(find(keyCode));
                RTsimuljudge=secs-ts;
                responsemat(trial,19)=RTsimuljudge;


                if simulkey==KbName(keyCodes.Left) %left key press=no
                    responsemat(trial,10)=0; %sj answer
                    responsemat(trial,17)=1;
                elseif simulkey==KbName(keyCodes.Right) %right key press=yes
                    responsemat(trial,10)=1; %sj answer
                    responsemat(trial,17)=2;
                elseif simulkey == KbName(keyCodes.Escape)
                    Screen('CloseAll');
                    break;
                end

                FlushEvents();
                keyIsDown=0;
                causalkey=[];
                % ts=GetSecs;
                Screen('DrawTexture',wptr,cjqTexture,[],Rectstart);
                Screen('DrawTexture',wptr,yesTexture,[],Yesrect );
                Screen('DrawTexture',wptr,NoTexture,[],Norect );
                ts=GetSecs;
                Screen('Flip' , display.windowPtr);
                [secs, keyCode, deltaSecs] = KbPressWait;

                causalkey= KbName(find(keyCode));

                RTcausaljudge=secs-ts;
                responsemat(trial,20)=RTcausaljudge;

                if causalkey == KbName(keyCodes.Left) %left key press=no
                    responsemat(trial,9)=0; %cj answer
                    responsemat(trial,18)=1;
                elseif causalkey == KbName(keyCodes.Right)%right key press=yes
                    responsemat(trial,9)=1; %cj answer
                    responsemat(trial,18)=2;
                elseif causalkey == KbName(keyCodes.Escape)
                    Screen('CloseAll');
                    break;
                end

            end
        end
        responsemat(:,11)=TRAINorNOT; %0=main
        responsemat(:,12)=Subject;
        responsemat(trial,13)=gender; %Man=1 / Woman=2
        responsemat(trial,14)=dominantHand; %Left=1 / Right=2
        responsemat(trial,15)=age;
        str=sprintf('ResponseMat_blc%d_subj%d',block,Subject);
        save([[path_data f strname] f str ],'responsemat');
        TE(trial,block)=te;

        if block==1
            TT=trial;
        elseif block>1

            numberofTrial_T= sum(numberofTrial);
            TT= trial +numberofTrial_T;
        end



        ResponseMat_all(TT,:)=responsemat(trial,:);

        ResponseMat_all_valid = ResponseMat_all(ResponseMat_all(:,8)==1, :);
        RestrictKeysForKbCheck([]);
        meanRT=mean(ResponseMat_all_valid(:,6)  ,'all');
        meanRT_all(block)=meanRT;


        WaitSecs(ITI);
        trial=trial+1;

    end
    numberofTrial(block)=numTrial;
    tend=toc(tstart);


end


strResp=sprintf('data_set_main_%d',Subject);
save(strResp,'ResponseMat_all');
save([[path_data f strname] f strResp ],'ResponseMat_all');
strmean =sprintf('meanRTmain_subj_%d',Subject);
save([[path_data f strname] f strmean ],'meanRT_all');


meanRTfinalmain=mean(ResponseMat_all_valid(:,6)  ,'all');
save([path_means f strmean]   ,'meanRTfinalmain');

strte=sprintf('TEma_subject_%d',Subject);
save([[path_data f strname] f strte ],'TE');

performance_T=length(ResponseMat_all)/ResponseMat_all(ResponseMat_all(:,8)==1);
strper=sprintf('performancemain_subject_%d',Subject);
save([[path_data f strname] f strper ],'performance_T');


Screen('CloseAll');
WaitSecs(1);

%%
times=[-.300,-0.100,-0.030,0.030,0.100,.300]';

for g= 1:length(times)

    performance_D(g,1)= length(ResponseMat_all (ResponseMat_all(:,3)==times(g) & ResponseMat_all(:,8) ==1));
    performance_D(g,2)= length(ResponseMat_all(ResponseMat_all(:,3)==times(g)));
    performance_D(g,3)= (performance_D(g,1)./performance_D(g,2));

end

% figure('Name','total performance')
% plot(times,performance_D(:,3));


%%
% data of condition 1
ResponseMat_all_cond1= ResponseMat_all(ResponseMat_all_valid(:,2)==1 ,:);
% data of condition 2
ResponseMat_all_cond2= ResponseMat_all(ResponseMat_all_valid(:,2)==2 ,:);
% data of condition 3
ResponseMat_all_cond3= ResponseMat_all(ResponseMat_all(:,2)==3 ,:);

%%
performance_D3=length(ResponseMat_all_cond3(ResponseMat_all_cond3(:,7)==1 | ResponseMat_all_cond3(:,7)==2))/...
    length(ResponseMat_all_cond3(:,7));
strperd3=sprintf('performanced3main_subject_%d',Subject);
save([[path_data f strname] f strperd3 ],'performance_D3');
