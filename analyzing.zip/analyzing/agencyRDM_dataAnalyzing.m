
clear all
close all
clc
% setting path to current directory
path_ = cd;
%%
%loading data...
dataTable=table();

for s=1:20
    load(['data_set_main_',num2str(s),'.mat']);
    responseTable=array2table(ResponseMat_all,"VariableNames",["block number","condition",...
    "times","cueState","judgecond","RT","pressedkey","validation","cj","sj","trainORnot","Subject","gender",...
    "dominantHand","age","pressedkeycode","sjpressed","cjpressed","RTsimuljudge","RTcausaljudge"]);
    dataTable=[dataTable;responseTable];
end


%% calculating real time delay for each trial

dataTable=dataTable(dataTable.validation==1,:); % excluding wrong trials (too soon, too late, or wrong key errors)
dataTable.realdelay=nan(height(dataTable),1);
dataTable.meanrt=nan(height(dataTable),1);

TT=0;
for s=1:20
    load(['data_set_main_',num2str(s),'.mat']);
    ResponseMat_all=ResponseMat_all(ResponseMat_all(:,8)==1,:);
    for trial=1:length(ResponseMat_all)
        TT=TT+1;
        dataTable.meanrt(TT)=mean(ResponseMat_all(1:trial,6));

    end
    clear ResponseMat_all
end


for trial=1:height(dataTable)
    dataTable.realdelay(trial)=1000*((dataTable.meanrt(trial)+dataTable.times(trial))-dataTable.RT(trial));
    realtimes_subj(trial,1)=1000*((dataTable.meanrt(trial)+dataTable.times(trial))-dataTable.RT(trial));
    realtimes_subj(trial,2)=dataTable.Subject(trial);
    realtimes_subj(trial,3)=dataTable.condition(trial);
end

for s=1:20
    for c=1:3
        realtimes1_subj(:,s)=realtimes_subj((realtimes_subj(:,2)==s),1);
        realtimecond(:,c,s)=realtimes_subj((realtimes_subj(:,2)==s & realtimes_subj(:,3)==c ),1);
    end
end

%%
%remove raw data and delet subjects with low performance

dataTable= dataTable((dataTable.Subject~=1 & dataTable.Subject~=2 & dataTable.Subject~=14 & dataTable.Subject~=16 ),:);
realtimes=unique(dataTable.realdelay);

% uniqtimes=unique(realtimes);

dataTable1=dataTable(dataTable.condition==1,:); %force
dataTable2=dataTable(dataTable.condition==2,:); %free
dataTable3=dataTable(dataTable.condition==3,:); %phs

dataTable3=dataTable3(dataTable3.cueState==1 & dataTable3.pressedkeycode==1 ...
    |  dataTable3.cueState==2 & dataTable3.pressedkeycode==2,:); %excluding wrong responses to phs

%% time bins

edges=[-500,-240,-120,-60,0,60,120,240,500]; % defining time bins

for i=1:(length(edges)-1) %middle of each time bin
    mtd(i)=(edges(i)+edges(i+1))/2;
end

% save('mtd.mat','mtd')

%% calculating frequency of simultaneious and causal judgements for each time bin

binnum=length(edges)-1;
bin=(max(realtimes)-min(realtimes))/50;
subj=unique(dataTable.Subject);

for s=1:length(subj)

    for t=1:(length(edges)-1)

        % rows= delay time bins, culomn= percent of frequency of yes
        % answers for each subject in that bin

        % simultaniety judgement for condition1
        s1data(t,s,1)= length(dataTable1.sj(((d(t)<= dataTable1.realdelay) & (dataTable1.realdelay<d(t+1))) & (dataTable1.sj ==1) & (dataTable1.Subject==subj(s))));
        s1data(t,s,2)= length(dataTable1.sj(((d(t)<= dataTable1.realdelay) & (dataTable1.realdelay<d(t+1)))  & (dataTable1.Subject==subj(s))));
        s1data(t,s,3)= s1data(t,s,1)./s1data(t,s,2);
        if isnan(s1data(t,s,3))
            s1data(t,s,3)=0;
        end

        s2data(t,s,1)= length(dataTable2.sj(((d(t)<= dataTable2.realdelay) & (dataTable2.realdelay<d(t+1))) & (dataTable2.sj ==1) & (dataTable2.Subject==subj(s))));
        s2data(t,s,2)= length(dataTable2.sj(((d(t)<= dataTable2.realdelay) & (dataTable2.realdelay<d(t+1)))  & (dataTable2.Subject==subj(s))));
        s2data(t,s,3)= s2data(t,s,1)./s2data(t,s,2);
        if isnan(s2data(t,s,3))
            s2data(t,s,3)=0;
        end

        s3data(t,s,1)= length(dataTable3.sj(((d(t)<= dataTable3.realdelay) & (dataTable3.realdelay<d(t+1))) & (dataTable3.sj ==1) & (dataTable3.Subject==subj(s))));
        s3data(t,s,2)= length(dataTable3.sj(((d(t)<= dataTable3.realdelay) & (dataTable3.realdelay<d(t+1))) & (dataTable3.Subject==subj(s))));
        s3data(t,s,3)= s3data(t,s,1)./s3data(t,s,2);
        if isnan(s3data(t,s,3))
            s3data(t,s,3)=0;
        end

        % simultaniety judgement for condition1
        c1data(t,s,1)= length(dataTable1.cj(((d(t)<= dataTable1.realdelay) & (dataTable1.realdelay<d(t+1))) & (dataTable1.cj ==1) & (dataTable1.Subject==subj(s))));
        c1data(t,s,2)= length(dataTable1.cj(((d(t)<= dataTable1.realdelay) & (dataTable1.realdelay<d(t+1)))  & (dataTable1.Subject==subj(s))));
        c1data(t,s,3)= c1data(t,s,1)./c1data(t,s,2);
        if isnan(c1data(t,s,3))
            c1data(t,s,3)=0;
        end

        c2data(t,s,1)= length(dataTable2.cj(((d(t)<= dataTable2.realdelay) & (dataTable2.realdelay<d(t+1))) & (dataTable2.cj ==1) & (dataTable2.Subject==subj(s))));
        c2data(t,s,2)= length(dataTable2.cj(((d(t)<= dataTable2.realdelay) & (dataTable2.realdelay<d(t+1)))  & (dataTable2.Subject==subj(s))));
        c2data(t,s,3)= c2data(t,s,1)./c2data(t,s,2);
        if isnan(c2data(t,s,3))
            c2data(t,s,3)=0;
        end

        c3data(t,s,1)= length(dataTable3.cj(((d(t)<= dataTable3.realdelay) & (dataTable3.realdelay<d(t+1))) & (dataTable3.cj ==1) & (dataTable3.Subject==subj(s))));
        c3data(t,s,2)= length(dataTable3.cj(((d(t)<= dataTable3.realdelay) & (dataTable3.realdelay<d(t+1))) & (dataTable3.Subject==subj(s))));
        c3data(t,s,3)= c3data(t,s,1)./c3data(t,s,2);
        if isnan(c3data(t,s,3))
            c3data(t,s,3)=0;
        end

    end
end

%save('s1data.mat','s1data')
%save('s2data.mat','s2data')
%save('s3data.mat','s3data')
%save('c1data.mat','c1data')
%save('c2data.mat','c2data')
%save('c3data.mat','c3data')

%% signed-rank test of mean for simultaneity and causality judgements

% simultaneity
for t=1:binnum

    [ph_simul(t,1),ph_simul(t,2)]=signrank(s1data(t,:,3),s2data(t,:,3),"tail","both","method","exact","alpha",0.05); % force/free

    [ph_simul(t,3),ph_simul(t,4)]=signrank(s1data(t,:,3),s3data(t,:,3),"tail","both","method","exact","alpha",0.05); % force/phs

    [ph_simul(t,5), ph_simul(t,6)]=signrank(s2data(t,:,3),s3data(t,:,3),"tail","both","method","exact","alpha",0.05); % free/phs
end

% causality
for t=1:binnum

    [ph_causal(t,1),ph_causal(t,2)]=signrank(c1data(t,:,3),c2data(t,:,3),"tail","both","method","exact","alpha",0.05); % force/free

    [ph_causal(t,3),ph_causal(t,4)]=signrank(c1data(t,:,3),c3data(t,:,3),"tail","both","method","exact","alpha",0.05); % force/phs

    [ph_causal(t,5),ph_causal(t,6)]=signrank(c2data(t,:,3),c3data(t,:,3),"tail","both","method","exact","alpha",0.05); % free/phs

end

% save('ph_simul.mat','ph_simul')
% save('ph_causal.mat','ph_causal')

%% calculating mean, variance and SEM

%mean of percent of yes answers in each time bin, between all subjects / simultaniety

ms(:,1)= mean(s1data(:,:,3),2);
ms(:,2)=mean(s2data(:,:,3),2);
ms(:,3)=mean(s3data(:,:,3),2);

% mean of percent of yes answers in each time bin, between all subjects / causality
mc(:,1)=mean(c1data(:,:,3),2);
mc(:,2)=mean(c2data(:,:,3),2);
mc(:,3)=mean(c3data(:,:,3),2);

% variance of percent of yes answers in each time bin, between all subjects / simultaniety
vars(:,1)= var(s1data(:,:,3),0,2);
vars(:,2)=var(s2data(:,:,3),0,2);
vars(:,3)=var(s3data(:,:,3),0,2);

% variance of percent of yes answers in each time bin, between all subjects / causality
varc(:,1)=var(c1data(:,:,3),0,2);
varc(:,2)=var(c2data(:,:,3),0,2);
varc(:,3)=var(c3data(:,:,3),0,2);

% SEM (standard error of mean) for each time bin between subjects
err_simul(:,1)=std(s1data(:,:,3),0,2)./sqrt(length(subj));
err_simul(:,2)=std(s2data(:,:,3),0,2)./sqrt(length(subj));
err_simul(:,3)=std(s3data(:,:,3),0,2)./sqrt(length(subj));

err_causal(:,1)=std(c1data(:,:,3),0,2)./sqrt(length(subj));
err_causal(:,2)=std(c2data(:,:,3),0,2)./sqrt(length(subj));
err_causal(:,3)=std(c3data(:,:,3),0,2)./sqrt(length(subj));

%% plot simultaniety and causality mean frequency for all subjects (bar plot)

tit={'force','free','phs'};
f1=figure('Name','simultaniety for all subject');
f1.Position=[100 100 1100 700];
for t=1:3
    subplot(1,3,t)
    bar(mtd,ms(:,t),1)
    ylim([0 1])
    hold on

    errorbar(mtd,ms(:,t),err_simul(:,t),'s','MarkerFaceColor','r','MarkerSize',5)
    %     hold on
    %     plot(mtd,ms(:,t),"Color",'black','LineStyle','-.','MarkerSize',20)

    title(tit{t},'FontWeight', 'bold', 'FontSize', 12)
    xlabel('SOA (ms)','FontWeight', 'bold', 'FontSize', 10)
    ylabel('Proportion (mean of all subjects)','FontWeight', 'bold', 'FontSize', 10)
    xticks(mtd)
    yticks(0:.05:1)
    grid on
    set(gca, 'FontSize', 10, 'FontWeight', 'bold')

end
% saveas(f1,'simultanietyBar_all','jpg')


f2=figure('Name','causality for all subject');
f2.Position=[100 100 1100 700];
for t=1:3
    subplot(1,3,t)
    bar(mtd,mc(:,t),1)
    xticks(mtd)
    yticks(0:.05:1)
    ylim([0 1])
    hold on
    %     errorbar(mtd,mc(:,t),err_causal(:,t),'.')
    errorbar(mtd,mc(:,t),err_causal(:,t),'s','MarkerFaceColor','r','MarkerSize',5)
    %     hold on
    %     plot(mtd,mc(:,t),"Color",'black','LineStyle','-.','MarkerSize',20)

    title(tit{t},'FontWeight', 'bold', 'FontSize', 12)
    xlabel('SOA (ms)','FontWeight', 'bold', 'FontSize', 10)
    ylabel('Proportion (mean of all subjects)','FontWeight', 'bold', 'FontSize', 10)
    grid on
    set(gca, 'FontSize', 10, 'FontWeight', 'bold')
end
% saveas(f2,'causalityBar_all','jpg')
%% plot simultaniety and causality mean frequency for all subjects (curve)
figure('Name','simultaneity curve')
plot(mtd,ms(:,1),'LineWidth',1)
hold on
plot(mtd,ms(:,2),'LineWidth',1)
hold on
plot(mtd,ms(:,3),'LineWidth',1)
legend('force','free','phs')
grid on
ylim([0 1])
xticks(mtd)
yticks(0:.05:1)
xlabel('real time delay')
ylabel('mean of percent of yes response')

%
figure('Name','causality curve')
plot(mtd,mc(:,1),'LineWidth',1)
hold on
plot(mtd,mc(:,2),'LineWidth',1)
hold on
plot(mtd,mc(:,3),'LineWidth',1)
legend('force','free','phs')
grid on
ylim([0 1])
xticks(mtd)
yticks(0:.05:1)
xlabel('real time delay')
ylabel('mean of percent of yes response')

%% corcoefficeint analyzing 
%% *simultaneity*
%%
%free/phs
for s=1:16

    [R,P]=corrcoef( s2data(:,s,3), s3data(:,s,3));
    R_S_23(s)=1-R(1,2);
    R_S23(s)=R(1,2);
end
[ps23,hs23]=signrank(R_S_23)
%%
% Initialize parameters
num_permutations = 1000;    % Number of permutations
num_features=16;
R_S23 = zeros(1, 16);       % Array to store observed correlation coefficients
p_values = zeros(1, 16);    % Array to store p-values

for s = 1:16
    % Calculate the observed correlation between the two datasets
    [R, ~] = corrcoef(s2data(:, s, 3), s3data(:, s, 3));
    R_S23(s) = R(1, 2);  % Store the observed correlation coefficient
    P_S23(s) = 1 - R_S23(s);
    % Initialize an array to store the permuted correlation coefficients
    permuted_correlations = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle the data in one dataset
        shuffled_data = s3data(randperm(size(s3data, 1)), s, 3); % Randomly shuffle rows

        % Calculate the correlation coefficient for the shuffled data
        [R_perm, ~] = corrcoef(s2data(:, s, 3), shuffled_data);
        permuted_correlations(perm) = 1-R_perm(1, 2); % Store the permuted correlation
    end

    % Calculate the p-value for the observed correlation
    % p-value = proportion of permutations that are as extreme or more extreme than the observed correlation
    p_values(s) = sum(abs(permuted_correlations) >= abs(P_S23(s))) / num_permutations;
end

% Display results
disp('Observed Correlations:');
disp(R_S23);
disp('p-values:');
disp(p_values);
% Optional: Use signrank to test if medians of observed correlations differ from zero
[ps23, hs23] = signrank(P_S23,p_values);

% Display results from signrank
disp(['Signrank p-value: ', num2str(ps23)]);
disp(['Hypothesis Test Result (hs12): ', num2str(hs23)]);
%%
%force/phs
for s=1:16

    [R,P]=corrcoef( s1data(:,s,3), s3data(:,s,3));
    R_S_13(s)=1-R(1,2);
    P_S_13(s)=R(1,2)
end
[ps13,hs13]=signrank(R_S_13)
%%
R_S13 = zeros(1, num_features);        % Array to store observed correlation coefficients
P_S13 = zeros(1, num_features);        % Array to store complements of the correlation coefficients
p_values_S13 = zeros(1, num_features); % Array to store p-values from permutation tests

% Calculate observed correlation coefficients
for s = 1:num_features
    % Calculate the correlation coefficient between s1data and s3data
    [R, ~] = corrcoef(s1data(:, s, 3), s3data(:, s, 3));
    R_S13(s) = R(1, 2);      % Store observed correlation coefficient
    P_S13(s) = 1 - R_S13(s); % Calculate and store the complement of the correlation
end

% Display observed correlations and their complements
disp('Observed Correlation Coefficients (s1data & s3data):');
disp(R_S13);
disp('Complement of Correlation Coefficients:');
disp(P_S13);

% Perform permutation test
for s = 1:num_features
    % Initialize an array to store permuted correlation coefficients
    permuted_correlations = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle s3data for permutation
        shuffled_data = s3data(randperm(size(s3data, 1)), s, 3);

        % Calculate the correlation coefficient with the shuffled data
        [R_perm, ~] = corrcoef(s1data(:, s, 3), shuffled_data);
        permuted_correlations(perm) = 1-R_perm(1, 2); % Store the permuted correlation
    end

    % Calculate the p-value for the observed correlation
    p_values_S13(s) = sum(abs(permuted_correlations) >= abs(P_S13(s))) / num_permutations;
end

% Display permutation p-values
disp('Permutation p-values:');
disp(p_values_S13);

% Optional: Use signrank to test if medians of observed correlations differ from zero
[ps13, hs13] = signrank(P_S13,p_values_S13);

% Display results from signrank
disp(['Signrank p-value: ', num2str(ps13)]);
disp(['Hypothesis Test Result (hs12): ', num2str(hs13)]);
%% *causality*
%%
%force/free
for s=1:16

    [R,P]=corrcoef( s1data(:,s,3), s2data(:,s,3));
    R_S_12(s)=1-R(1,2);
    P_S_12(s)=R(1,2)
end
[ps12,hs12]=signrank(R_S_12)
%%
R_S12 = zeros(1, num_features); % Array to store observed correlation coefficients
P_S12 = zeros(1, num_features); % Array to store the complement of the correlation coefficients


% Calculate observed correlation coefficients
for s = 1:num_features
    [R, ~] = corrcoef(s1data(:, s, 3), s2data(:, s, 3));
    R_S12(s) = R(1, 2);      % Store observed correlation coefficient
    P_S12(s) = 1 - R_S12(s); % Calculate and store the complement of the correlation
end

% Display observed correlations and their complements
disp('Observed Correlation Coefficients (s1data & s2data):');
disp(R_S12);
disp('Complement of Correlation Coefficients:');
disp(P_S12);

% Perform permutation test to calculate p-values
p_values_S12 = zeros(1, num_features); % Array to store p-values for permutations

for s = 1:num_features
    % Initialize an array for permuted correlations
    permuted_correlations = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle s2data for permutation
        shuffled_data = s2data(randperm(size(s2data, 1)), s, 3);

        % Calculate the correlation coefficient for shuffled data
        [R_perm, ~] = corrcoef(s1data(:, s, 3), shuffled_data);
        permuted_correlations(perm) =1- R_perm(1, 2); % Store the permuted correlation
    end

    % Calculate the p-value for the observed correlation
    p_values_S12(s) = sum(abs(permuted_correlations) >= abs(P_S12(s))) / num_permutations;
end

% Display permutation p-values
disp('Permutation p-values:');
disp(p_values_S12);

% Optional: Use signrank to test if medians of observed correlations differ from zero
[ps12, hs12] = signrank(P_S12,p_values_S12);

% Display results from signrank
disp(['Signrank p-value: ', num2str(ps12)]);
disp(['Hypothesis Test Result (hs12): ', num2str(hs12)]);
%%
%force/phs
for s=1:16

    [R,P]=corrcoef( c1data(:,s,3), c3data(:,s,3));
    R_C_13(s)=1-R(1,2);
    P_C_13(s)=R(1,2)
end
[pc13,hc13]=signrank(R_C_13)
%%
R_C13 = zeros(1, 16);       % Array to store observed correlation coefficients
P_C13 = zeros(1, 16);       % Array to store the complement of the correlation coefficients
p_values_C13 = zeros(1, 16); % Array to store p-values

% Calculate observed correlation coefficients
for s = 1:16
    [R, ~] = corrcoef(c1data(:, s, 3), c3data(:, s, 3));
    R_C13(s) = R(1, 2);       % Store observed correlation coefficient
    P_C13(s) = 1 - R_C13(s);  % Complement of the correlation
end

% Perform permutation test for statistical significance
for s = 1:16
    % Initialize an array for permuted correlations
    permuted_correlations = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle c3data for permutation
        shuffled_data = c3data(randperm(size(c3data, 1)), s, 3);

        % Calculate the correlation coefficient for shuffled data
        [R_perm, ~] = corrcoef(c1data(:, s, 3), shuffled_data);
        permuted_correlations(perm) = 1-R_perm(1, 2); % Store the permuted correlation
    end

    % Calculate the p-value for the observed correlation
    p_values_C13(s) = sum(abs(permuted_correlations) >= abs(P_C13(s))) / num_permutations;
end

% Display observed correlations and p-values
disp('Observed Correlation Coefficients (c1data & c3data):');
disp(R_C13);
disp('Complement of Correlation Coefficients:');
disp(P_C13);
disp('Permutation p-values:');
disp(p_values_C13);

% Optional: Use signrank to test if medians of observed correlations differ from 0
[pc13, hc13] = signrank(P_C13,p_values_C13);

% Display results from signrank
disp(['Signrank p-value: ', num2str(pc13)]);
disp(['Hypothesis Test Result (hc13): ', num2str(hc13)]);
%%
%free/phs
R_C_23=nan(1,16)
for s=1:16

    [R,P]=corrcoef( c2data(:,s,3), c3data(:,s,3));
    R_C_23(s)=1-R(1,2);
    P_C_23(s)=R(1,2);
end
[pc23,hc23]=signrank(R_C_23)
%%
% force/free
R_C23 = zeros(1, 16);       % Array to store observed correlation coefficients
P_C23 = zeros(1, 16);       % Array to store the complement of the correlation coefficients
p_values_C23 = zeros(1, 16); % Array to store p-values

for s = 1:16
    % Calculate the observed correlation coefficient
    [R, ~] = corrcoef(c2data(:, s, 3), c3data(:, s, 3));
    R_C23(s) = R(1, 2);       % Store observed correlation coefficient
    % Calculate the complement of the correlation
    P_C23(s) = 1 - R_C23(s);

    % Initialize an array to store permuted correlation coefficients
    permuted_correlations = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle the data in one dataset (c3data)
        shuffled_data = c3data(randperm(size(c3data, 1)), s, 3); % Randomly shuffle rows

        % Calculate the correlation coefficient for the shuffled data
        [R_perm, ~] = corrcoef(c2data(:, s, 3), shuffled_data);
        permuted_correlations(perm) =1- R_perm(1, 2); % Store the permuted correlation
    end

    % Calculate the p-value for the observed correlation
    p_values_C23(s) = sum(abs(permuted_correlations) >= abs(P_C23(s))) / num_permutations;
end
[p,h]=signrank(p_values,P_C23)
% Display results from signrank
disp(['Signrank p-value: ', num2str(p)]);
disp(['Hypothesis Test Result (hc13): ', num2str(h)]);

%% *corrcoef-causal/simul*
%%
%force
for s=1:16

    [R,P]=corrcoef( s1data(:,s,3), c1data(:,s,3));
    R_cs_1(s)=1-R(1,2);
    %     P_C_12(t)=P(1,2)
end
[pcs1,hcs1]=signrank(R_cs_1)
%%

R_cs_1 = zeros(1, num_features);       % Array to store complements of the correlation coefficients (1 - R)
p_values_cs_1 = zeros(1, num_features); % Array to store p-values from permutation tests

% Calculate observed complements (1 - R) for each feature
for s = 1:num_features
    % Calculate the correlation coefficient between s1data and c1data
    [R, ~] = corrcoef(s1data(:, s, 3), c1data(:, s, 3));
    R_cs_1(s) = 1 - R(1, 2); % Store the complement (1 - R)
end

% Display observed complements
disp('Observed Complements of Correlation Coefficients (1 - R):');
disp(R_cs_1);

% Perform permutation test for 1 - R
for s = 1:num_features
    % Initialize an array to store permuted complements (1 - R)
    permuted_complements = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle c1data for permutation
        shuffled_data = c1data(randperm(size(c1data, 1)), s, 3);

        % Calculate the correlation coefficient with the shuffled data
        [R_perm, ~] = corrcoef(s1data(:, s, 3), shuffled_data);
        permuted_complements(perm) = 1 - R_perm(1, 2); % Store the permuted complement (1 - R)
    end

    % Calculate the p-value for the observed complement (1 - R)
    p_values_cs_1(s) = sum(abs(permuted_complements) >= abs(R_cs_1(s))) / num_permutations;
end

% Display permutation p-values
disp('Permutation p-values for complements (1 - R):');
disp(p_values_cs_1);

% Sign rank test
[ps_cs_1, hs_cs_1] = signrank(R_cs_1,p_values_cs_1); % Testing the median of complements against zero

% Display Signrank results
disp(['Signrank p-value: ', num2str(ps_cs_1)]);
disp(['Hypothesis Test Result (hs_cs_1): ', num2str(hs_cs_1)]);
%%
%free
for s=1:16

    [R,P]=corrcoef( s2data(:,s,3), c2data(:,s,3));
    R_cs_2(s)=1-R(1,2);
    %     P_C_12(t)=P(1,2)
end

[pcs2,hcs2]=signrank(R_cs_2)
%%
R_cs_2 = zeros(1, num_features);        % Array to store complements of the correlation coefficients (1 - R)
p_values_cs_2 = zeros(1, num_features); % Array to store p-values from permutation tests

% Calculate observed complements (1 - R) for each feature
for s = 1:num_features
    % Calculate the correlation coefficient between s2data and c2data
    [R, ~] = corrcoef(s2data(:, s, 3), c2data(:, s, 3));
    R_cs_2(s) = 1 - R(1, 2); % Store the complement (1 - R)
end

% Display observed complements
disp('Observed Complements of Correlation Coefficients (1 - R):');
disp(R_cs_2);

% Perform permutation test for 1 - R
for s = 1:num_features
    % Initialize an array to store permuted complements (1 - R)
    permuted_complements = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle c2data for permutation
        shuffled_data = c2data(randperm(size(c2data, 1)), s, 3);

        % Calculate the correlation coefficient with the shuffled data
        [R_perm, ~] = corrcoef(s2data(:, s, 3), shuffled_data);
        permuted_complements(perm) = 1 - R_perm(1, 2); % Store the permuted complement (1 - R)
    end

    % Calculate the p-value for the observed complement (1 - R)
    p_values_cs_2(s) = sum(abs(permuted_complements) >= abs(R_cs_2(s))) / num_permutations;
end

% Display permutation p-values
disp('Permutation p-values for complements (1 - R):');
disp(p_values_cs_2);

% Sign rank test
[ps_cs_2, hs_cs_2] = signrank(R_cs_2,p_values_cs_2); % Testing the median of complements against zero

% Display Signrank results
disp(['Signrank p-value: ', num2str(ps_cs_2)]);
disp(['Hypothesis Test Result (hs_cs_2): ', num2str(hs_cs_2)]);
%%
%phs
for s=1:16

    [R,P]=corrcoef( s3data(:,s,3), c3data(:,s,3));
    R_cs_3(s)=1-R(1,2);
    %     P_C_12(t)=P(1,2)
end

[pcs3,hcs3]=signrank(R_cs_1)
%%

R_cs_3 = zeros(1, num_features);        % Array to store complements of the correlation coefficients (1 - R)
p_values_cs_3 = zeros(1, num_features); % Array to store p-values from permutation tests

% Calculate observed complements (1 - R) for each feature
for s = 1:num_features
    % Calculate the correlation coefficient between s3data and c3data
    [R, ~] = corrcoef(s3data(:, s, 3), c3data(:, s, 3));
    R_cs_3(s) = 1 - R(1, 2); % Store the complement (1 - R)
end

% Display observed complements
disp('Observed Complements of Correlation Coefficients (1 - R):');
disp(R_cs_3);

% Perform permutation test for 1 - R
for s = 1:num_features
    % Initialize an array to store permuted complements (1 - R)
    permuted_complements = zeros(1, num_permutations);

    for perm = 1:num_permutations
        % Shuffle c3data for permutation
        shuffled_data = c3data(randperm(size(c3data, 1)), s, 3);

        % Calculate the correlation coefficient with the shuffled data
        [R_perm, ~] = corrcoef(s3data(:, s, 3), shuffled_data);
        permuted_complements(perm) = 1 - R_perm(1, 2); % Store the permuted complement (1 - R)
    end

    % Calculate the p-value for the observed complement (1 - R)
    p_values_cs_3(s) = sum(abs(permuted_complements) >= abs(R_cs_3(s))) / num_permutations;
end

% Display permutation p-values
disp('Permutation p-values for complements (1 - R):');
disp(p_values_cs_3);

% Sign rank test
[ps_cs_3, hs_cs_3] = signrank(R_cs_3,p_values_cs_3); % Testing the median of complements against zero

% Display Signrank results
disp(['Signrank p-value: ', num2str(ps_cs_3)]);
disp(['Hypothesis Test Result (hs_cs_3): ', num2str(hs_cs_3)]);


