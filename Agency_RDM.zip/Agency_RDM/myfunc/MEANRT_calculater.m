function meanRTresult = MEANRT_calculater(TRAINorNOT,Subject)


% addpath('exampledata')
 addpath('meandata')
% exampledataTable=table();

% for d=1:5
%    load(['data_set_',num2str(d),'.mat']);
%     responseTable=array2table(ResponseMat_all,"VariableNames",["block number","condition",...
%         "times","cueState","judgecond","RT","pressedkey","validation","cj","sj"]);
%     exampledataTable=[exampledataTable;responseTable];
% end
% 
% exampledataTable=exampledataTable (exampledataTable.validation==1,:);
% 
% exampleMeanRT=mean(exampledataTable.RT);

if TRAINorNOT==1

    meanRTresult=0.5203;

elseif TRAINorNOT==0
    load(['meanRTtrain_subj_',num2str(Subject),'.mat']);
    meanRTresult= meanRTfinaltr;



end

end

