%% Set display parameters
%
display.dist = 70;  %cm distance from monitor
display.width = 30; %cm
display.skipChecks = 1; %avoid Screen's timing checks and verbosity
PsychImaging('PrepareConfiguration');
PsychImaging('AddTask', 'General', 'UseRetinaResolution');

global wHeight;
global wWidth;

display = OpenWindow(display);
  wptr=display.windowPtr;
    wWidth=display.resolution(1);
    wHeight=display.resolution(2);
green=[0 255 0];
yellow=[255 255 0];
center = display.resolution/2;
xCenter=center(1);
yCenter=center(2);
grCenter=[xCenter-wWidth/5 , yCenter];
yelCenter= [xCenter+wWidth/5 , yCenter];
a=angle2pix(display,0.450);
greenRect= [grCenter(1)-a grCenter(2)-a grCenter(1)+a grCenter(2)+a];
yellowRect= [yelCenter(1)-a yelCenter(2)-a yelCenter(1)+a yelCenter(2)+a];
windowPtr=display.windowPtr;
 Screen('FillRect', windowPtr, green , cueRect )
 Screen('Flip' , windowPtr);
 KbWait();
 Screen('Flip' , windowPtr);
 sca

 