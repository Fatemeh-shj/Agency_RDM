
function [RT,key,duration,te,X,Y,Gd]=NewMovingDot(display,dots,meanRT,latency,cond,cueState,keyCodes)
% movingDots(display,dots,duration)
%
% Animates a field of moving dots based on parameters defined in the 'dots'
% structure over a period of seconds defined by 'duration'.
%MovingDots
% The 'dots' structure must have the following parameters:
%
%   nDots            Number of dots in the field
%   speed            Speed of the dots (degrees/second)
%   direction        Direction 0-360 clockwise from upward
%   lifetime         Number of frames for each dot to live
%   apertureSize     [x,y] size of circular aperture (degrees)
%   center           [x,y] Center of the aperture (degrees)
%   color            Color of the dot field [r,g,b] from 0-255
%   size             Size of the dots (in pixels)
%   coherence        Coherence from 0 (incoherent) to 1 (coherent)
%
% 'dots' can be an array of structures so that multiple fields of dots can
% be shown at the same time.  The order that the dots are drawn is
% scrambled across fields so that one field won't occlude another.
%
% The 'display' structure requires the fields:
%    width           Width of screen (cm)
%    dist            Distance from screen (cm)
% And can also use the fields:
%    skipChecks      If 1, turns off timing checks and verbosity (default 0)
%    fixation        Information about fixation (see 'insertFixation.m')
%    screenNum       screen number
%    bkColor         background color (default is [0,0,0])
%    windowPtr       window pointer, set by 'OpenWindow'
%    frameRate       frame rate, set by 'OpenWindow'
%    resolution      pixel resolution, set by 'OpenWindow'

% Fatemeh Jannesari,2023
display.frameRate
key=[];
%Calculate total number of dots across fields
nDots = sum([dots.nDots]);

%Zero out the color and size vectors
colors = zeros(3,nDots);
sizes = zeros(1,nDots);
% S=angle2pix(display,0.149);
% sizes=S;
%Generate a random order to draw the dots so that one field won't occlude
%another field.
order=  randperm(nDots);
global wWidth
global wHeight
Dur=latency+meanRT;
duration=horzcat(Dur,.130,1-Dur);
coherency=[0,1,0];
speed=[.1,6,.1];
RT=[];
GD=[];
Rectstart=[0 0 wWidth wHeight];  

% KbQueueCreate();
%% Loop through the frames
keyIsDown=0;
FlushEvents();
KbName('UnifyKeyNames');
ActiveKeys=[KbName('ESCAPE'), KbName('d'),KbName('l') ];

RestrictKeysForKbCheck(ActiveKeys);
for d=1:length(duration)
    nFrames(d) = secs2frames(display,duration(d));
end
m=[1,nFrames(1);(nFrames(1)+1),(nFrames(1)+nFrames(2));...
    (nFrames(1)+nFrames(2)+1),(nFrames(1)+nFrames(2)+nFrames(3))];
    GD=zeros(sum(nFrames),dots.nDots);
    pix_y=zeros(sum(nFrames),dots.nDots);
    pix_x=zeros(sum(nFrames),dots.nDots);
%  tt=GetSecs();
for d=1:length(duration)

    nFrames(d) = secs2frames(display,duration(d));
    dots.coherence=coherency(d);
    dots.speed=speed(d);
    count = 1;
    Screen('BlendFunction',display.windowPtr , GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    for i=1:length(dots) %Loop through the fields


        %Calculate the left, right top and bottom of each aperture (in degrees)
        l(i) = dots(i).center(1)-dots(i).apertureSize(1)/2;
        r(i) = dots(i).center(1)+dots(i).apertureSize(1)/2;
        b(i) = dots(i).center(2)-dots(i).apertureSize(2)/2;
        t(i) = dots(i).center(2)+dots(i).apertureSize(2)/2;

        %Generate random starting positions
        dots(i).x = (rand(1,dots(i).nDots)-.5)*dots(i).apertureSize(1) + dots(i).center(1);
        dots(i).y = (rand(1,dots(i).nDots)-.5)*dots(i).apertureSize(2) + dots(i).center(2);

        %Create a direction vector for a given coherence level
        direction = rand(1,dots(i).nDots)*360;
        nCoherent = ceil(dots(i).coherence*dots(i).nDots);  %Start w/ all random directions
        direction(1:nCoherent) = dots(i).direction;  %Set the 'coherent' directions

        %Calculate dx and dy vectors in real-world coordinates
        dots(i).dx = -dots(i).speed*cos(direction*pi/180)/display.frameRate;
        dots(i).dy = dots(i).speed*sin(direction*pi/180)/display.frameRate;
        dots(i).life = ceil(rand(1,dots(i).nDots)*dots(i).lifetime);
        %Fill in the 'colors' and 'sizes' vectors for this field
        id = count:(count+dots(i).nDots-1);  %index into the nDots length vector for this field
        colors(:,order(id)) = repmat(dots(i).color(:),1,dots(i).nDots);

        sizes(order(id)) = repmat(dots(i).size,1,dots(i).nDots);

        count = count+dots(i).nDots;
    end


    %Zero out the screen position vectors and the 'goodDots' vector
    pixpos.x = zeros(1,nDots);
    pixpos.y = zeros(1,nDots);
    



    for frameNum=1:nFrames(d)
        count = 1;
       
        for i=1:length(dots)  %Loop through the fields

            %Update the dot position's real-world coordinates
            dots(i).x = dots(i).x + dots(i).dx;
            dots(i).y = dots(i).y + dots(i).dy;


            %Move the dots that are outside the aperture back one aperture width.
            dots(i).x(dots(i).x<l(i)) = dots(i).x(dots(i).x<l(i)) + dots(i).apertureSize(1);
            dots(i).x(dots(i).x>r(i)) = dots(i).x(dots(i).x>r(i)) - dots(i).apertureSize(1);
            dots(i).y(dots(i).y<b(i)) = dots(i).y(dots(i).y<b(i)) + dots(i).apertureSize(2);
            dots(i).y(dots(i).y>t(i)) = dots(i).y(dots(i).y>t(i)) - dots(i).apertureSize(2);

            %Increment the 'life' of each dot
            dots(i).life = dots(i).life+1;

            %Find the 'dead' dots
            deadDots = mod(dots(i).life,dots(i).lifetime)==0;

            %Replace the positions of the dead dots to random locations
            dots(i).x(deadDots) = (rand(1,sum(deadDots))-.5)*dots(i).apertureSize(1) + dots(i).center(1);
            dots(i).y(deadDots) = (rand(1,sum(deadDots))-.5)*dots(i).apertureSize(2) + dots(i).center(2);

            %Calculate the index for this field's dots into the whole list of
            %dots.  Using the vector 'order' means that, for example, the first
            %field is represented not in the first n values, but rather is
            %distributed throughout the whole list.
            id = order(count:(count+dots(i).nDots-1));

            %Calculate the screen positions for this field from the real-world coordinates
            pixpos.x(id) = angle2pix(display,dots(i).x)+ display.resolution(1)/2;
            pixpos.y(id) = angle2pix(display,dots(i).y)+ display.resolution(2)/2;


            %Determine which of the dots in this field are outside this field's
            %circular aperture
            goodDots(id) = (dots(i).x-dots(i).center(1)).^2/(dots(i).apertureSize(1)/2)^2 + ...
                (dots(i).y-dots(i).center(2)).^2/(dots(i).apertureSize(2)/2)^2 < 1;

            count = count+dots(i).nDots;

        end
        if d==1
            ff=frameNum;
        elseif d==2
            ff=frameNum+nFrames(1);
        elseif d==3
            ff=frameNum+nFrames(1)+nFrames(2);
        end
            X(ff,:)=pixpos.x;
            Y(ff,:)=pixpos.y;
            Gd(ff,:)=goodDots;


    end

end

%%
topPriorityLevel=MaxPriority(display.windowPtr);


ifi=Screen('GetFlipInterval',display.windowPtr);

Priority(topPriorityLevel);

% 


      Screen('BlendFunction',display.windowPtr , GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      T = 1000./display.frameRate;

      % T = ifi/1000;
       TStart=GetSecs;
      key=[];
    % tt=GetSecs();
     tt=tic();
    for ff=1:sum(nFrames)
        % ff
        t0=GetSecs();
        
        %Draw all fields at once
        GD=Gd(ff,:);
        pix_x=[X(ff,:)];
        pix_y=[Y(ff,:)];


        Screen('DrawDots',display.windowPtr,[pix_x(GD);pix_y(GD)], dots.size, [255 255 255],[0,0],3);

        [VBLTimestamp ,StimulusOnsetTime ,FlipTimestamp , Missed Beampos]=Screen('Flip' , display.windowPtr,0);
% 
%             vbl1=abs(VBLTimestamp-FlipTimestamp)
            pressed = 0;
            while (1000*(GetSecs()-t0))<T
                
                 [keyIsDown,secs,keyCode]=KbCheck;

                if keyIsDown==1 && ~pressed
                    % RT=toc(tt)
                    key=KbName(find(keyCode));
                   
                     RT=secs- TStart
                    % tt1=toc(tt)
                    pressed = 1;
                end


                WaitSecs(.001);
            end

pressedKeyCode=KbName(key);
%         if  RT<.350 | (GetSecs-tt>0.750 & isempty(key))
%             break;        
%         end
% if cond==1
%     if (pressedKeyCode == keyCodes.Left & cueState==2) | (pressedKeyCode == keyCodes.Right & cueState==1)
%         break;
%     end
% end

if  RT<.350 | (toc(tt)>0.751 & isempty(key))
    break;
end
if cond==1
    if (pressedKeyCode == keyCodes.Left & cueState==2) | (pressedKeyCode == keyCodes.Right & cueState==1)
        break;
    end
end
% 


t1=GetSecs-t0;
    end


Priority(0);

% te=GetSecs()-tt
te=toc(tt);
RestrictKeysForKbCheck([]);

if isempty(RT)
    RT=2;
end
